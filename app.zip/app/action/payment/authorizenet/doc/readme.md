# This documentation and the objects it documents have been deprecated

See new sample code GitHub repository at https://github.com/AuthorizeNet/sample-code-php
