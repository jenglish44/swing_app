<?php
header('Access-Control-Allow-Origin: *');
$li=mysql_connect('localhost','swingd','Allowme1ce!');
mysql_select_db('swingd',$li);
//$li=mysql_connect('swingd.db.9223379.hostedresource.com','swingd','Allowme1ce!');
//mysql_select_db('swingd',$li);
//$li=mysql_connect('localhost','root','');
//mysql_select_db('swingd',$li);

?>